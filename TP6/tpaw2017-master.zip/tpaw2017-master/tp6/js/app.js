/* App Module */
var meteoApp = angular.module('meteoApp', ['ngRoute', 'meteoControllers']);
