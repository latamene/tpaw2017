TP6 - angular 1

Demo : https://bilelz.github.io/tpaw2017/tp6/
